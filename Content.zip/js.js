function tap(i, i1){
    js.tap(i, i1);
}
function setToolBarText(i){
js.setToolBarText(i);
}
